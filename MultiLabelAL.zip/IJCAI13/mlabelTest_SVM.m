function [funvals, f0, predY] = mlabelTest_SVM(model, X, Y)
if nargin < 3
    n = size(X,1);
    k = length(model);
    Y = randi(1,n,k);
else
    [n,k] = size(Y);
end

if ~issparse(X)
    X = sparse(X);
end

predY = zeros(n,k);
funvals = zeros(n,k);
f0 = zeros(n,1);

for svm_idx = 1:k
    [predY(:,svm_idx), ~, funvals(:,svm_idx)] = linearpredict(double(Y(:,svm_idx)), double(X), model(svm_idx));
end