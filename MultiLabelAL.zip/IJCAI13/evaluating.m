function metric = evaluating(predY, trueY, measure)
% 8 evaluation metrics are computed:
%   -- 1: Hamming Loss
%   -- 2: Exact Matching Ratio
%   -- 3: Accuracy
%   -- 4: F-Macro
%   -- 5: Precision
%   -- 6: Recall
%   -- 7: F-Micro

[n,l] = size(predY);
switch measure
    case 'ham' % hamming loss
        metric = sum(sum(predY~=trueY))/(n*l);
    case 'emr' % exact matching ratio
        metric = sum(sum(predY~=trueY,2)==0)/n;
    case 'acc' % accuracy
        metric = sum(sum(predY==1 & trueY==1,2)./sum(predY==1 | trueY==1,2))/n;
    case 'fma' % F1-Macro
        metric = sum(2*sum(predY==1 & trueY==1)./(sum(predY==1)+sum(trueY==1)))/l;
    case 'pre' % precision
        metric = sum(sum(predY==1 & trueY==1,2)./(sum(predY==1,2)+0.000001))/n;
    case 'rec' % recall
        metric = sum(sum(predY==1 & trueY==1,2)./sum(trueY==1,2))/n;
    case 'fmi' % F1-Micro
        metric = 2*sum(sum(predY==1 & trueY==1,2))/(sum(sum(trueY==1,2))+sum(sum(predY==1,2))); 
end