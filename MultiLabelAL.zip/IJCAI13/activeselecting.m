function [batch, time] =activeselecting(Ldata, Llabels, Udata, W, beta, options, subsampling,...
    batchsize, active, classnum)
%
% input:
% Udata: n x d, unlabeled data
% W: weight matrix d x 1
% options:
%   -- kernels parameters
%          KernelType  -  Choices are:
%               'Gaussian'      - e^{-(|x-y|^2)/2t^2}
%               'Polynomial'    - (x'*y)^d
%               'PolyPlus'      - (x'*y+1)^d
%               'Linear'        -  x'*y
%
%               t       -  parameter for Gaussian
%               d       -  parameter for Poly
%   -- 2D active learning indicator
%          involveLabel - values can be:
%           1: consider label density
%           0: consider instance density
% subsampling: method to select a subset as candidate
% subsampling.method
%   0: use all
%	1: clustering
%	2: random selection
% subsampling.num
%	number of candidates
%
% batchsize: batch size
% active: 1 = active selection; 0 = random selection
%
% output:
% batch: batchsize x 1, the indice of queried instances in Udata
%
% Xin Li
% Dec. 2011
%

[ut, d] = size(Udata); % d: num of features
time = 0;
tStop =0;

%%===================Active Learning Procedure==============
if active
    % step 1: sampling the candidate set
    if  subsampling.method == 1 % cluster
        [ctrs,] = vl_kmeans(Udata', 300, 'verbose', '', 'algorithm', 'elkan');
        [~, ~, ~, Dist] = vl_kmeans(Udata,subsampling.num,'Replicates',...
            10,'Maxiter',300,'EmptyAction','singleton','Display','off');
        [~, ids] = min(Dist);
        cand_ids = unique(ids);
    elseif subsampling.method == 2 % random sampling
        if subsampling.num>=ut
            cand_ids = 1:ut;
        else
            tmp = randperm(ut);
            cand_ids = tmp(1:subsampling.num);
        end
    else % use all
        cand_ids = 1:ut;
    end
    
    % step 2: calculate the uncertainty
    [funvals, f0, prediction] = mlabelTest_SVM(W,Udata(cand_ids,:)); % cand_ids -> 1:ut
    
    funvals_pos = funvals-repmat(f0,1,classnum);
    funvals_pos(prediction<=0) = Inf; % eliminate all negative values
    funvals_neg = funvals-repmat(f0,1,classnum);
    funvals_neg(prediction>0) = -Inf; % eliminate all positive values
    uncertainty = 1./(min(funvals_pos,[],2)-max(funvals_neg,[],2)+0.000001); % avoiding divided by 0
    
    % normalize uncertainty
    uncertainty = (uncertainty-min(uncertainty))/(max(uncertainty)-min(uncertainty));
    
    if length(beta)==1
        if beta~=1
            %                 mutualinfo = getmutualinfo(cand_ids, uK, invU);
            if options.involveLabel==1 % use label density
                density = getLabelSim(Llabels,Udata(cand_ids,:), W, 'Ratio');
            else % use instance density
                density = getDensity(Udata(cand_ids,:));
            end
            measures = (uncertainty.^beta).*(density.^(1-beta));
        else % beta=1, which means ignoring mutualinfo/density
            %                 measures = hingeloss;
            measures = uncertainty;
        end
        [~, index1] = max(measures); % adding the instance index
    else
        %             mutualinfo = getmutualinfo(cand_ids, uK, invU);
        if options.involveLabel==1 % Use label density
            density = getLabelSim(Llabels,Udata(cand_ids,:), W, 'Ratio');
        else % use instance density
            density = getDensity(Udata(cand_ids,:));
        end
        for i=1:length(beta)
            measures(:,i) = (uncertainty.^beta(i)).*(density.^(1-beta(i))); % measures: n x betasize
        end
        [~, indice] = max(measures);
        indice = unique(indice); % get rid of redundancy
        tic;
        for j=1:length(indice)
            %add this unlabeled data into labeled set
            tempLdata = [Ldata;Udata(cand_ids(indice(j)),:)];
            tempLlabels = [Llabels;prediction(indice(j),:)];
            %retrain
            %                weights = MLabelTrain2(tempLdata, tempLlabels, 1);
            weights = MLabelTrain_SVM(tempLdata, tempLlabels, options.C);
            %remove this unlabeled data from unlabeled set
            tempUdata = Udata;
            tempUdata(cand_ids(indice(j)),:) = [];
            %predicting on unlabeled set
            %                [funvals_temp, f0_temp, pred_temp] = mlabelTest(weights,tempUdata);
            [funvals_temp, f0_temp, pred_temp] = mlabelTest_SVM(weights,tempUdata);
            %calculate measures
            kesi_temp = 1-funvals_temp+repmat(f0_temp,1,classnum);
            ita_temp = 1+funvals_temp-repmat(f0_temp,1,classnum);
            kesi_temp(kesi_temp<0|pred_temp==0)=0;
            ita_temp(ita_temp<0|pred_temp==1)=0;
            hingeloss_temp(:,j) = sum(kesi_temp+ita_temp,2);
        end
        tStop = toc;
        %pick the minimum one
        [~,index1] = min(sum(hingeloss_temp));
        index1 = indice(index1);
    end
    
    batch = cand_ids(index1); % return the instance index
    time = tStop;
else % batch_mode
    [~,idx_orig] = sort(hingeloss,'descend'); % sampling based on hingeloss
    [~,~,~,dists] = kmeans(Udata(cand_ids(idx_orig(1:60),:)),batchsize); % do clustering
    [~,temp] = min(dists);
    batch = cand_ids(idx_orig(temp));
end