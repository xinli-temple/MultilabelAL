function model = MLabelTrain_SVM(X, Y, C)

[n,k] = size(Y);
option = sprintf('-c %d -q', C);

for svm_idx=1:k
     % Train binary SVM classifiers
     model(svm_idx) = lineartrain(double(Y(:,svm_idx)), sparse(double(X)), option); % train model
end