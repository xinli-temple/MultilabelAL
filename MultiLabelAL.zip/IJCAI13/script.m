clear;

%% +++++++++++++++++++++++++data preparation+++++++++++++++++++++++++++

load('corel5k_s1_data.mat');
load('corel5k_s1_labels.mat');
load('corel5k_s1_labeled.mat');
load('corel5k_s1_unlabeled.mat');
load('corel5k_s1_testing.mat');
data = double(feats); % data is n x d matrix
labels = double(labels); % labels is n x k matrix
ltX = data(idxs_l,:);
ltY = labels(idxs_l,:);
utX = data(idxs_u,:);
utY = labels(idxs_u,:);
sX = data(idxs_t,:);
sY = labels(idxs_t,:);

%% Parameter Setting
C =100; % trade-off parameter
iterations = 100; % budget of queries
batchsize = 1; % one instance per query
options.C = C;
options.involveLabel = 0;
options.KernelType = 'Gaussian';
options.t = 2; %parameters of kernel
options.involveLabel = 1; % consider LCI
% subsampling.method
%	1: clustering
%	2: random selection
%	3: use all
% subsampling.num
subsampling.method = 2;
subsampling.num = 400;  % size of sampled subset
beta = 0.5;

%% ++++++++++++++++++++++++++++Proposed 2D Method+++++++++++++++++++++++++++++
W = MLabelTrain_SVM(ltX,ltY,C);
[~, ~, preds] = mlabelTest_SVM(W, sX, sY);
Active2DResult = zeros(length(idxs_t),size(sY,2),iterations+1);
Active2DResult(:,:, 1) =preds;

fprintf('--Active selection begins...\n');

for iter_idx = 1:iterations
        % Active Learning
        [batch, efet]= activeselecting(ltX, ltY, utX, W, ...
                beta, options, subsampling, batchsize, 1, size(sY,2));
        ltX = [ltX; utX(batch,:)]; % adding selected instances into labeled set
        ltY = [ltY; utY(batch,:)]; % querying their labels
        
        %remove instances and their labels from unlabeled set
        utX(batch,:) = [];
        utY(batch,:) = [];
        
        W = MLabelTrain_SVM(ltX, ltY, C);
        [~, ~, pred] = mlabelTest_SVM(W, sX, sY);
        Active2DResult(:,:,1+iter_idx) = pred;
end
fprintf('================Done===============\n');